import os
import sys
import getpass
import requests
import zipfile
from io import BytesIO
import shutil

# --- Clase para manejar códigos de color ANSI ---
class Color:
    """Códigos de color ANSI para terminales."""
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKCYAN = '\033[96m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'

# --- Configuraciones LOCALES ---
NOMBRE_SCRIPT_BASH = ".bash_pp"
NOMBRE_SCRIPT_PYTHON = os.path.basename(__file__)
NOMBRE_CARPETA_DESTINO = "PP"
HOME_DIR = os.path.expanduser("~")
RUTA_BASHRC = os.path.join(HOME_DIR, ".bashrc")
NOMBRE_USUARIO = getpass.getuser()

CARPETA_DESTINO_PP = os.path.join(HOME_DIR, NOMBRE_CARPETA_DESTINO)
RUTA_SCRIPT_DESTINO_COMPLETA = os.path.join(CARPETA_DESTINO_PP, NOMBRE_SCRIPT_BASH)
RUTA_PYTHON_DESTINO_COMPLETA = os.path.join(CARPETA_DESTINO_PP, NOMBRE_SCRIPT_PYTHON)

# Configuración del ZIP 
SUBCARPETA_EN_ZIP = "PP" 
NOMBRE_SCRIPT_BASH_EN_ZIP = os.path.join(SUBCARPETA_EN_ZIP, NOMBRE_SCRIPT_BASH)
NOMBRE_ARCHIVO_ZIP = "PP.zip" 
ZIP_URL = f"https://raw.githubusercontent.com/a101mdtbb/pp/main/{NOMBRE_ARCHIVO_ZIP}"

def print_status(message, status):
    """Imprime un mensaje con color según el estado."""
    if status == "SUCCESS":
        print(f"{Color.OKGREEN}{Color.BOLD}✅ ÉXITO:{Color.ENDC} {message}")
    elif status == "FAIL":
        print(f"{Color.FAIL}{Color.BOLD}❌ ERROR:{Color.ENDC} {message}")
    elif status == "WARN":
        print(f"{Color.WARNING}{Color.BOLD}⚠️ ATENCIÓN:{Color.ENDC} {message}")
    elif status == "INFO":
        print(f"{Color.OKBLUE}{Color.BOLD}▶️ INFO:{Color.ENDC} {message}")
    elif status == "HEADER":
        print(f"\n{Color.HEADER}{Color.BOLD}*** {message} ***{Color.ENDC}")
    else:
        print(message)

def descargar_e_instalar_bash_pp():
    """Descarga el ZIP, extrae .bash_pp (desde la subcarpeta PP/) y lo coloca en ~/PP/."""

    print_status(f"Iniciando Descarga/Actualización de {NOMBRE_SCRIPT_BASH}...", "HEADER")
    print_status(f"Fuente del ZIP en GitHub: {ZIP_URL}", "INFO")

    # 1. Descargar el archivo ZIP en memoria
    print_status("1. Conectando a GitHub para descargar el archivo ZIP...", "INFO")
    try:
        response = requests.get(ZIP_URL, stream=True, timeout=30)
        response.raise_for_status() 
        zip_content = BytesIO(response.content)
        print_status(f"Descarga exitosa. Tamaño: {len(zip_content.getvalue()) / 1024:.2f} KB.", "SUCCESS")
    except requests.exceptions.RequestException as e:
        print_status(f"Error al descargar el ZIP desde GitHub. Error: {e}", "FAIL")
        print_status(f"La URL utilizada fue: {ZIP_URL}", "FAIL")
        sys.exit(1)

    # 2. Extracción y movimiento de .bash_pp
    print_status(f"2. Extrayendo '{NOMBRE_SCRIPT_BASH}' (desde {SUBCARPETA_EN_ZIP}/) y sobrescribiendo la versión local...", "HEADER")
    
    RUTA_TEMP_EXTRACCION = os.path.join(CARPETA_DESTINO_PP, "temp_extract_bash")
    os.makedirs(RUTA_TEMP_EXTRACCION, exist_ok=True)
    
    try:
        with zipfile.ZipFile(zip_content, 'r') as zip_ref:
            if NOMBRE_SCRIPT_BASH_EN_ZIP not in zip_ref.namelist():
                print_status(f"El archivo '{NOMBRE_SCRIPT_BASH_EN_ZIP}' no fue encontrado en el ZIP.", "FAIL")
                print_status(f"Archivos encontrados: {zip_ref.namelist()}", "INFO")
                sys.exit(1)
            
            # Extraer SOLO el archivo con su ruta completa
            zip_ref.extract(NOMBRE_SCRIPT_BASH_EN_ZIP, RUTA_TEMP_EXTRACCION)
            
            RUTA_ARCHIVO_EXTRAIDO = os.path.join(RUTA_TEMP_EXTRACCION, NOMBRE_SCRIPT_BASH_EN_ZIP)
            
            # Movemos el archivo a la ubicación final, sobrescribiendo el existente
            shutil.move(RUTA_ARCHIVO_EXTRAIDO, RUTA_SCRIPT_DESTINO_COMPLETA)
            
            os.chmod(RUTA_SCRIPT_DESTINO_COMPLETA, 0o644) 
            
            print_status(f"'{NOMBRE_SCRIPT_BASH}' actualizado exitosamente en {RUTA_SCRIPT_DESTINO_COMPLETA}.", "SUCCESS")
            
    except Exception as e:
        print_status(f"Error inesperado al extraer/mover el archivo: {e}", "FAIL")
        sys.exit(1)
    finally:
        # 3. Limpieza de la carpeta temporal
        if os.path.exists(RUTA_TEMP_EXTRACCION):
            shutil.rmtree(RUTA_TEMP_EXTRACCION)

def copiar_script_python_local():
    """Copia el archivo Python actual (pp.py) a la carpeta de destino ~/PP/."""
    
    print_status(f"Iniciando Paso 2: Copiar el script de actualización ({NOMBRE_SCRIPT_PYTHON})...", "HEADER")
    
    RUTA_ARCHIVO_ORIGEN = os.path.abspath(__file__)
    
    if RUTA_ARCHIVO_ORIGEN == RUTA_PYTHON_DESTINO_COMPLETA:
        print_status("El script ya se está ejecutando desde la ubicación final. No es necesario copiar.", "WARN")
        return
        
    try:
        shutil.copy2(RUTA_ARCHIVO_ORIGEN, RUTA_PYTHON_DESTINO_COMPLETA)
        print_status(f"Copia exitosa de '{NOMBRE_SCRIPT_PYTHON}' a {CARPETA_DESTINO_PP}/", "SUCCESS")
        
    except Exception as e:
        print_status(f"Error al copiar el script Python a la carpeta de destino: {e}", "FAIL")
        sys.exit(1)


def automatizar_configuracion():
    """Realiza los pasos de instalación (creación de carpeta, descarga/actualización, y modificación de .bashrc)."""
    
    # Usando $HOME para la ruta genérica y alias pp-update (CORREGIDO)
    ruta_generica_pp_py = os.path.join("$HOME", NOMBRE_CARPETA_DESTINO, NOMBRE_SCRIPT_PYTHON)

    contenido_bashrc = f"""

# --- INICIO DE CONFIGURACIÓN AUTOMATIZADA ({NOMBRE_SCRIPT_BASH}) ---
if [ -f {RUTA_SCRIPT_DESTINO_COMPLETA} ]; then
  . {RUTA_SCRIPT_DESTINO_COMPLETA}
fi

# Alias para facilitar la actualización de la paquetería PP (Genérico para cualquier usuario)
alias pp-update='python3 {ruta_generica_pp_py}'

# --- FIN DE CONFIGURACIÓN AUTOMATIZADA ---

"""
    print(f"\n{Color.OKCYAN}{Color.BOLD}*** INICIO DE PROCESO DE INSTALACIÓN/ACTUALIZACIÓN ***{Color.ENDC}")
    print(f"  {Color.BOLD}Carpeta Destino:{Color.ENDC} {CARPETA_DESTINO_PP}")

    # --- PASO 1: Crear la carpeta de destino PP ---
    print_status(f"Paso 1: Crear la carpeta {NOMBRE_CARPETA_DESTINO}...", "HEADER")
    try:
        os.makedirs(CARPETA_DESTINO_PP, exist_ok=True)
        print_status(f"Carpeta creada o ya existente en: {CARPETA_DESTINO_PP}", "SUCCESS")
    except Exception as e:
        print_status(f"Error al crear la carpeta {CARPETA_DESTINO_PP}: {e}", "FAIL")
        sys.exit(1)

    # --- PASO 2: Copiar el Script Python (Autocopia) ---
    copiar_script_python_local()
    
    # --- PASO 3: Descargar, Extraer e Instalar/Actualizar .bash_pp ---
    descargar_e_instalar_bash_pp()
    
    # --- PASO 4: Modificar el archivo .bashrc (Solo si es la primera vez) ---
    print_status("Paso 4: Modificar el archivo .bashrc...", "HEADER")
    try:
        with open(RUTA_BASHRC, 'r') as f:
            contenido_actual = f.read()

        # Comprobación de existencia de la línea de carga
        if RUTA_SCRIPT_DESTINO_COMPLETA in contenido_actual:
            print_status(f"La configuración de carga ya existe en {RUTA_BASHRC}.", "WARN")
        else:
            with open(RUTA_BASHRC, 'a') as f:
                f.write(contenido_bashrc)
            # El alias instalado es pp-update (CORREGIDO)
            print_status(f"Contenido de carga y alias 'pp-update' agregados exitosamente a {RUTA_BASHRC}.", "SUCCESS")

    except Exception as e:
        print_status(f"Error al modificar .bashrc: {e}", "FAIL")
        sys.exit(1)

    # --- Finalización simplificada, moderna y organizada ---
    
    print(f"\n{Color.OKCYAN}{Color.BOLD}========================================={Color.ENDC}")
    print(f"{Color.OKCYAN}{Color.BOLD}🚀 PAQUETERÍA PP INSTALADA/ACTUALIZADA 🚀{Color.ENDC}")
    print(f"{Color.OKCYAN}{Color.BOLD}========================================={Color.ENDC}")

    print_status("✅ Paquetes PP (.bash_pp) listos para usar.", "SUCCESS")
    print_status(f"🛠️  Actualizador (pp.py) ubicado en: {CARPETA_DESTINO_PP}/", "INFO")
    
    print("\n--- INSTRUCCIONES RÁPIDAS (IMPORTANTE) ---")
    
    # 1. Instrucción para recargar: Usando el alias pp-upgrade
    print(f"{Color.WARNING}1. Para cargar los nuevos paquetes (comandos) en esta terminal, use el alias:{Color.ENDC}")
    print(f"   {Color.BOLD}pp-upgrade{Color.ENDC}")
    print(f"   (Este alias recarga su configuración y activa todos los comandos).")

    # 2. Instrucción para futuras actualizaciones: Usando el alias pp-update (CORREGIDO)
    print(f"\n{Color.WARNING}2. Para actualizar la paquetería PP en el futuro, use el alias:{Color.ENDC}")
    print(f"   {Color.BOLD}pp-update{Color.ENDC}")
    print("-----------------------------------------")


if __name__ == "__main__":
    # Verificación de dependencias
    try:
        import requests
    except ImportError:
        print_status("La librería 'requests' no está instalada.", "FAIL")
        print_status("Instálala usando: pip install requests o pip3 install requests", "FAIL")
        sys.exit(1)

    automatizar_configuracion()
